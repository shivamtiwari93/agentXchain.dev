import { writeFileSync, readFileSync, existsSync, mkdirSync, readdirSync } from 'fs';
import { join, resolve, dirname } from 'path';
import { fileURLToPath } from 'url';
import chalk from 'chalk';
import inquirer from 'inquirer';
import { CONFIG_FILE, LOCK_FILE, STATE_FILE } from '../lib/config.js';
import { generateVSCodeFiles } from '../lib/generate-vscode.js';
import { loadGovernedTemplate, VALID_GOVERNED_TEMPLATE_IDS } from '../lib/governed-templates.js';
import { VALID_PROMPT_TRANSPORTS } from '../lib/normalized-config.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const TEMPLATES_DIR = join(__dirname, '../templates');

const DEFAULT_AGENTS = {
  pm: {
    name: 'Product Manager',
    mandate: 'You think like a founder. Your only question is: would someone pay for this?\n\nEVERY TURN: 1) Prioritized list of what to build next (max 3 items). 2) Acceptance criteria for each. 3) One purchase blocker and its fix.\n\nCHALLENGE: If the dev over-engineered, call it out. If QA tested the wrong thing, redirect. If anyone is building for developers instead of users, shut it down.\n\nFIRST TURN: Write the MVP scope: who is the user, what is the core workflow, what are the max 5 features for v1.\n\nDON\'T: write code, design UI, or test. You decide what gets built and why.'
  },
  dev: {
    name: 'Fullstack Developer',
    mandate: 'You write production code, not prototypes. Every turn produces files that run.\n\nEVERY TURN: 1) Working code that executes. 2) Tests for what you built. 3) List of files changed. 4) Test suite output.\n\nCHALLENGE: If requirements are vague, refuse until they\'re specific. If QA found a bug, fix it properly.\n\nFIRST TURN: Set up the project: package.json, folder structure, database, health endpoint, one passing test.\n\nDON\'T: write pseudocode, skip tests, say "I would implement X" — implement it.'
  },
  qa: {
    name: 'QA Engineer',
    mandate: 'You are the quality gatekeeper. You test BOTH the code (functional) AND the user experience (UX). Nothing ships without your evidence.\n\nFUNCTIONAL QA every turn: 1) Run test suite, report pass/fail. 2) Test against acceptance criteria in .planning/REQUIREMENTS.md. 3) Test unhappy paths: empty input, wrong types, duplicates, expired sessions. 4) Write one test the dev didn\'t. 5) File bugs in .planning/qa/BUGS.md with repro steps.\n\nUX QA every turn (if UI exists): Walk through .planning/qa/UX-AUDIT.md checklist. Test first impressions, core flow, forms, responsive (375/768/1440px), accessibility (contrast, keyboard, alt text), error states.\n\nDOCS YOU MAINTAIN: .planning/qa/BUGS.md, UX-AUDIT.md, TEST-COVERAGE.md, ACCEPTANCE-MATRIX.md, REGRESSION-LOG.md.\n\nSHIP VERDICT every turn: "Can we ship?" YES / YES WITH CONDITIONS / NO + blockers.\n\nCHALLENGE: Verify independently. Test what others skip. Don\'t trust "it works."\n\nFIRST TURN: Set up test infra, create TEST-COVERAGE.md from requirements, initialize UX-AUDIT.md, create ACCEPTANCE-MATRIX.md.\n\nDON\'T: say "looks good." Don\'t skip UX. Don\'t file vague bugs.'
  },
  ux: {
    name: 'UX Reviewer & Context Manager',
    mandate: 'You are two things: a first-time user advocate and the team\'s memory manager.\n\nUX REVIEW EVERY TURN: 1) Use the product as a first-time user. 2) Flag confusing labels, broken flows, missing feedback, accessibility issues. 3) One specific UX improvement with before/after description.\n\nCONTEXT MANAGEMENT: If the log exceeds the word limit, compress older turns into a summary. Keep: scope decisions, open bugs, architecture choices, current phase. Cut: resolved debates, verbose status updates.\n\nCHALLENGE: If the dev built something unusable, flag it before QA wastes time testing it. If the PM\'s scope creates a confusing experience, say so.\n\nDON\'T: write backend code. Don\'t redesign from scratch. Suggest incremental UX fixes.'
  }
};

function slugify(name) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

function loadTemplates() {
  const templates = [];
  try {
    const files = readdirSync(TEMPLATES_DIR).filter(f => f.endsWith('.json'));
    for (const file of files) {
      const raw = readFileSync(join(TEMPLATES_DIR, file), 'utf8');
      const tmpl = JSON.parse(raw);
      templates.push({ id: file.replace('.json', ''), ...tmpl });
    }
  } catch {}
  return templates;
}

function interpolateTemplateContent(contentTemplate, projectName) {
  return contentTemplate.replaceAll('{{project_name}}', projectName);
}

function appendPromptOverride(basePrompt, override) {
  if (!override || !override.trim()) return basePrompt;
  return `${basePrompt}\n\n---\n\n## Project-Type-Specific Guidance\n\n${override.trim()}\n`;
}

function appendAcceptanceHints(baseMatrix, acceptanceHints) {
  if (!Array.isArray(acceptanceHints) || acceptanceHints.length === 0) {
    return baseMatrix;
  }

  const hintLines = acceptanceHints.map((hint) => `- [ ] ${hint}`).join('\n');
  return `${baseMatrix}\n\n## Template Guidance\n${hintLines}\n`;
}

// ── Governed init ───────────────────────────────────────────────────────────

const GOVERNED_ROLES = {
  pm: {
    title: 'Product Manager',
    mandate: 'Protect user value, scope clarity, and acceptance criteria.',
    write_authority: 'review_only',
    runtime: 'manual-pm'
  },
  dev: {
    title: 'Developer',
    mandate: 'Implement approved work safely and verify behavior.',
    write_authority: 'authoritative',
    runtime: 'local-dev'
  },
  qa: {
    title: 'QA',
    mandate: 'Challenge correctness, acceptance coverage, and ship readiness.',
    write_authority: 'review_only',
    runtime: 'api-qa'
  },
  eng_director: {
    title: 'Engineering Director',
    mandate: 'Resolve tactical deadlocks and enforce technical coherence.',
    write_authority: 'review_only',
    runtime: 'manual-director'
  }
};

const DEFAULT_GOVERNED_LOCAL_DEV_RUNTIME = Object.freeze({
  type: 'local_cli',
  command: ['claude', '--print'],
  cwd: '.',
  prompt_transport: 'stdin',
});

const GOVERNED_RUNTIMES = {
  'manual-pm': { type: 'manual' },
  'local-dev': DEFAULT_GOVERNED_LOCAL_DEV_RUNTIME,
  'api-qa': { type: 'api_proxy', provider: 'anthropic', model: 'claude-sonnet-4-6', auth_env: 'ANTHROPIC_API_KEY' },
  'manual-director': { type: 'manual' }
};

const GOVERNED_ROUTING = {
  planning: {
    entry_role: 'pm',
    allowed_next_roles: ['pm', 'eng_director', 'human'],
    exit_gate: 'planning_signoff'
  },
  implementation: {
    entry_role: 'dev',
    allowed_next_roles: ['dev', 'qa', 'eng_director', 'human'],
    exit_gate: 'implementation_complete'
  },
  qa: {
    entry_role: 'qa',
    allowed_next_roles: ['dev', 'qa', 'eng_director', 'human'],
    exit_gate: 'qa_ship_verdict'
  }
};

const GOVERNED_GATES = {
  planning_signoff: {
    requires_files: ['.planning/PM_SIGNOFF.md', '.planning/ROADMAP.md'],
    requires_human_approval: true
  },
  implementation_complete: {
    requires_verification_pass: true
  },
  qa_ship_verdict: {
    requires_files: ['.planning/acceptance-matrix.md', '.planning/ship-verdict.md'],
    requires_human_approval: true
  }
};

function buildGovernedPrompt(roleId, role) {
  const rolePrompts = {
    pm: buildPmPrompt,
    dev: buildDevPrompt,
    qa: buildQaPrompt,
    eng_director: buildEngDirectorPrompt,
  };

  const builder = rolePrompts[roleId];
  if (builder) return builder(role);

  // Fallback for custom roles
  return buildGenericPrompt(roleId, role);
}

function buildPmPrompt(role) {
  return `# Product Manager — Role Prompt

You are the Product Manager. Your mandate: **${role.mandate}**

## What You Do Each Turn

1. **Read the previous turn** (from CONTEXT.md). Understand what was done and what decisions were made.
2. **Challenge it.** Even if the work looks correct, identify at least one risk, scope gap, or assumption worth questioning. Rubber-stamping violates the protocol.
3. **Create or refine planning artifacts:**
   - \`.planning/ROADMAP.md\` — what will be built, in what order, with acceptance criteria
   - \`.planning/PM_SIGNOFF.md\` — your formal sign-off when planning is complete
   - \`.planning/acceptance-matrix.md\` — the acceptance criteria checklist for QA
4. **Propose the next role.** Typically \`dev\` after planning is complete, or \`eng_director\` if there's a technical deadlock.

## Planning Phase Exit

To exit the planning phase, you must:
- Ensure \`.planning/PM_SIGNOFF.md\` exists with your explicit sign-off
- Ensure \`.planning/ROADMAP.md\` exists with clear acceptance criteria
- Set \`phase_transition_request: "implementation"\` in your turn result

The orchestrator will evaluate the gate and may require human approval.

## Scope Authority

You define **what** gets built and **why**. You do not define **how** — that's the developer's domain. If you disagree with a technical approach, raise an objection with rationale, but do not override implementation decisions.

## Acceptance Criteria Quality

Every roadmap item must have acceptance criteria that are:
- **Observable** — can be verified by running code or inspecting output
- **Specific** — not "works well" but "returns 200 for GET /api/users with valid token"
- **Complete** — covers happy path, error cases, and edge cases worth testing
`;
}

function buildDevPrompt(role) {
  return `# Developer — Role Prompt

You are the Developer. Your mandate: **${role.mandate}**

## What You Do Each Turn

1. **Read the previous turn and ROADMAP.md.** Understand what you're building and what the acceptance criteria are.
2. **Challenge the previous turn.** If the PM's acceptance criteria are ambiguous, flag it. If QA's objections are unfounded, explain why. Never skip this.
3. **Implement the work.**
   - Write clean, correct code that meets the acceptance criteria
   - Run tests and include the results as verification evidence
   - Accurately list every file you changed in \`files_changed\`
4. **Verify your work.** Run the test suite, linter, or build command. Record the commands and exit codes in \`verification.machine_evidence\`.

## Implementation Rules

- Only implement what the roadmap and acceptance criteria require. Do not add unrequested features.
- If acceptance criteria are unclear, set \`status: "needs_human"\` and explain what needs clarification in \`needs_human_reason\`.
- If you encounter a technical blocker, set \`status: "blocked"\` and describe it.

## Verification Is Mandatory

You must run verification commands and report them honestly:
- \`verification.status\` must be \`"pass"\` only if all commands exited with code 0
- \`verification.machine_evidence\` must list every command you ran with its actual exit code
- Do NOT claim \`"pass"\` if you did not run the tests

## Phase Transition

When your implementation is complete and verified:
- If the implementation phase gate requires verification pass: ensure tests pass
- Set \`phase_transition_request: "qa"\` to advance to QA
- The gate may auto-advance or require human approval depending on config

## Artifact Type

Your artifact type is \`workspace\` (direct file modifications). The orchestrator will diff your changes against the pre-turn snapshot to verify \`files_changed\` accuracy.
`;
}

function buildQaPrompt(role) {
  return `# QA — Role Prompt

You are QA. Your mandate: **${role.mandate}**

## What You Do Each Turn

1. **Read the previous turn, the ROADMAP, and the acceptance matrix.** Understand what was built and what the acceptance criteria are.
2. **Challenge the implementation.** You MUST raise at least one objection — this is a protocol requirement for review_only roles. If the code is perfect, challenge the test coverage, the edge cases, or the documentation.
3. **Evaluate against acceptance criteria.** Go through each criterion and determine pass/fail.
4. **Create review artifacts:**
   - \`.planning/acceptance-matrix.md\` — updated with pass/fail verdicts per criterion
   - \`.planning/ship-verdict.md\` — your overall ship/no-ship recommendation

## You Cannot Modify Code

You have \`review_only\` write authority. You may NOT modify product files. You may only create/modify files under \`.planning/\` and \`.agentxchain/reviews/\`. Your artifact type must be \`review\`.

## Objection Requirement

You MUST raise at least one objection in your turn result. An empty \`objections\` array is a protocol violation and will be rejected by the validator. If the work is genuinely excellent, raise a low-severity observation about test coverage, documentation, or future risk.

Each objection must have:
- \`id\`: pattern \`OBJ-NNN\`
- \`severity\`: \`low\`, \`medium\`, \`high\`, or \`blocking\`
- \`against_turn_id\`: the turn you're challenging
- \`statement\`: clear description of the issue
- \`status\`: \`"raised"\`

## Blocking vs. Non-Blocking

- \`blocking\` severity means the work cannot ship. Use sparingly and only for real defects.
- \`high\` severity means significant risk but potentially shippable with mitigation.
- \`medium\` and \`low\` are observations that improve quality but don't block.

## Ship Verdict & Run Completion

When you are satisfied the work meets acceptance criteria:
1. Create \`.planning/ship-verdict.md\` with your verdict
2. Create/update \`.planning/acceptance-matrix.md\` with all criteria checked
3. Set \`run_completion_request: true\` in your turn result

**Only set \`run_completion_request: true\` when:**
- All blocking objections from prior turns are resolved
- The acceptance matrix shows all critical criteria passing
- \`.planning/ship-verdict.md\` exists with an affirmative verdict

**Do NOT set \`run_completion_request: true\` if:**
- You have unresolved blocking objections
- Critical acceptance criteria are failing
- You need the developer to fix issues first (propose \`dev\` as next role instead)

## Routing After QA

- If issues found → propose \`dev\` as next role (they fix, then you re-review)
- If ship-ready → set \`run_completion_request: true\`
- If deadlocked → propose \`eng_director\` or \`human\`
`;
}

function buildEngDirectorPrompt(role) {
  return `# Engineering Director — Role Prompt

You are the Engineering Director. Your mandate: **${role.mandate}**

## When You Are Called

You are invoked when the normal PM → Dev → QA loop is stuck:
- Repeated QA/Dev cycles without convergence
- Technical disagreement between roles
- Scope dispute that the PM cannot resolve
- Budget or timeline pressure requiring trade-offs

## What You Do Each Turn

1. **Read the full context.** Review the escalation reason, unresolved objections, and the decision history.
2. **Make a binding decision.** Your role is to break deadlocks, not to add more opinions. State your decision clearly with rationale.
3. **Challenge what led to the deadlock.** Identify the root cause — unclear acceptance criteria? Wrong technical approach? Scope creep?
4. **Route back to the appropriate role.** After your decision, the normal loop should resume.

## Decision Authority

- You may override QA objections if they are unreasonable or out of scope
- You may override PM scope decisions if they create technical impossibility
- You may NOT override human decisions — escalate to \`human\` if needed
- Every override must be recorded as a decision with clear rationale

## You Cannot Modify Code

You have \`review_only\` write authority. Like QA, you must raise at least one objection (protocol requirement). Your artifact type is \`review\`.

## Objection Requirement

You MUST raise at least one objection. Typically this will be about the process failure that led to your involvement — why did the loop deadlock? What should be done differently next time?

## Escalation to Human

If you cannot resolve the deadlock:
- Set \`status: "needs_human"\`
- Explain the situation in \`needs_human_reason\`
- The orchestrator will pause the run for human input
`;
}

function buildGenericPrompt(roleId, role) {
  return `# ${role.title} — Role Prompt

You are the **${role.title}** on this project.

**Mandate:** ${role.mandate}
**Write authority:** ${role.write_authority}

## What You Do Each Turn

1. Read the previous turn and challenge it explicitly.
2. Do your work according to your mandate.
3. Write your structured turn result to the turn-scoped staging path printed by the orchestrator (\`.agentxchain/staging/<turn_id>/turn-result.json\`).

## File Access

${role.write_authority === 'authoritative'
    ? 'You may modify product files directly.'
    : role.write_authority === 'proposed'
      ? 'You may propose changes via patches.'
      : 'You may NOT modify product files. Only create review artifacts under `.planning/` and `.agentxchain/reviews/`.'}
`;
}

function commandHasPromptPlaceholder(parts = []) {
  return parts.some((part) => typeof part === 'string' && part.includes('{prompt}'));
}

function resolveGovernedLocalDevRuntime(opts = {}) {
  const customCommand = Array.isArray(opts.devCommand)
    ? opts.devCommand.map((part) => String(part).trim()).filter(Boolean)
    : null;
  const explicitTransport = typeof opts.devPromptTransport === 'string' && opts.devPromptTransport.trim()
    ? opts.devPromptTransport.trim()
    : null;

  if (explicitTransport && !VALID_PROMPT_TRANSPORTS.includes(explicitTransport)) {
    throw new Error(`Unknown --dev-prompt-transport "${explicitTransport}". Valid values: ${VALID_PROMPT_TRANSPORTS.join(', ')}`);
  }

  if (!customCommand?.length) {
    const command = [...DEFAULT_GOVERNED_LOCAL_DEV_RUNTIME.command];
    if (explicitTransport === 'argv') {
      throw new Error('Default local dev command does not include {prompt}. Use --dev-command ... {prompt} for argv mode.');
    }
    return {
      runtime: {
        ...DEFAULT_GOVERNED_LOCAL_DEV_RUNTIME,
        command,
        prompt_transport: explicitTransport || DEFAULT_GOVERNED_LOCAL_DEV_RUNTIME.prompt_transport,
      },
    };
  }

  const hasPlaceholder = commandHasPromptPlaceholder(customCommand);

  if (!explicitTransport && !hasPlaceholder) {
    throw new Error('Custom --dev-command must either include {prompt} or set --dev-prompt-transport explicitly.');
  }

  if (explicitTransport === 'argv' && !hasPlaceholder) {
    throw new Error('--dev-prompt-transport argv requires {prompt} in --dev-command.');
  }

  if (explicitTransport && explicitTransport !== 'argv' && hasPlaceholder) {
    throw new Error(`--dev-prompt-transport ${explicitTransport} must not be combined with {prompt} in --dev-command.`);
  }

  return {
    runtime: {
      type: 'local_cli',
      command: customCommand,
      cwd: '.',
      prompt_transport: explicitTransport || 'argv',
    },
  };
}

function formatGovernedRuntimeCommand(runtime) {
  return Array.isArray(runtime?.command) ? runtime.command.join(' ') : String(runtime?.command || '');
}

export function scaffoldGoverned(dir, projectName, projectId, templateId = 'generic', runtimeOptions = {}) {
  const template = loadGovernedTemplate(templateId);
  const { runtime: localDevRuntime } = resolveGovernedLocalDevRuntime(runtimeOptions);
  const runtimes = {
    ...GOVERNED_RUNTIMES,
    'local-dev': localDevRuntime,
  };
  const config = {
    schema_version: '1.0',
    template: template.id,
    project: {
      id: projectId,
      name: projectName,
      default_branch: 'main'
    },
    roles: GOVERNED_ROLES,
    runtimes,
    routing: GOVERNED_ROUTING,
    gates: GOVERNED_GATES,
    budget: {
      per_turn_max_usd: 2.0,
      per_run_max_usd: 50.0,
      on_exceed: 'pause_and_escalate'
    },
    retention: {
      talk_strategy: 'append_only',
      history_strategy: 'jsonl_append_only'
    },
    prompts: {
      pm: '.agentxchain/prompts/pm.md',
      dev: '.agentxchain/prompts/dev.md',
      qa: '.agentxchain/prompts/qa.md',
      eng_director: '.agentxchain/prompts/eng_director.md'
    },
    rules: {
      challenge_required: true,
      max_turn_retries: 2,
      max_deadlock_cycles: 2
    }
  };

  const state = {
    schema_version: '1.1',
    run_id: null,
    project_id: projectId,
    status: 'idle',
    phase: 'planning',
    accepted_integration_ref: null,
    active_turns: {},
    turn_sequence: 0,
    last_completed_turn_id: null,
    blocked_on: null,
    blocked_reason: null,
    escalation: null,
    queued_phase_transition: null,
    queued_run_completion: null,
    phase_gate_status: {
      planning_signoff: 'pending',
      implementation_complete: 'pending',
      qa_ship_verdict: 'pending'
    },
    budget_reservations: {},
    budget_status: {
      spent_usd: 0,
      remaining_usd: config.budget.per_run_max_usd
    }
  };

  // Create directories
  mkdirSync(join(dir, '.agentxchain', 'staging'), { recursive: true });
  mkdirSync(join(dir, '.agentxchain', 'prompts'), { recursive: true });
  mkdirSync(join(dir, '.agentxchain', 'reviews'), { recursive: true });
  mkdirSync(join(dir, '.agentxchain', 'dispatch'), { recursive: true });
  mkdirSync(join(dir, '.planning'), { recursive: true });

  // Core governed files
  writeFileSync(join(dir, CONFIG_FILE), JSON.stringify(config, null, 2) + '\n');
  writeFileSync(join(dir, '.agentxchain', 'state.json'), JSON.stringify(state, null, 2) + '\n');
  writeFileSync(join(dir, '.agentxchain', 'history.jsonl'), '');
  writeFileSync(join(dir, '.agentxchain', 'decision-ledger.jsonl'), '');

  // Prompt templates
  for (const [roleId, role] of Object.entries(GOVERNED_ROLES)) {
    const basePrompt = buildGovernedPrompt(roleId, role);
    const prompt = appendPromptOverride(basePrompt, template.prompt_overrides?.[roleId]);
    writeFileSync(join(dir, '.agentxchain', 'prompts', `${roleId}.md`), prompt);
  }

  // Planning artifacts
  writeFileSync(join(dir, '.planning', 'PM_SIGNOFF.md'), `# PM Signoff — ${projectName}\n\nApproved: NO\n\n## Discovery Checklist\n- [ ] Target user defined\n- [ ] Core pain point defined\n- [ ] Core workflow defined\n- [ ] MVP scope defined\n- [ ] Out-of-scope list defined\n- [ ] Success metric defined\n\n## Notes for team\n(PM and human add final kickoff notes here.)\n`);
  writeFileSync(join(dir, '.planning', 'ROADMAP.md'), `# Roadmap — ${projectName}\n\n## Phases\n\n| Phase | Goal | Status |\n|-------|------|--------|\n| Planning | Align scope, requirements, acceptance criteria | In progress |\n| Implementation | Build and verify | Pending |\n| QA | Challenge correctness and ship readiness | Pending |\n`);
  const baseAcceptanceMatrix = `# Acceptance Matrix — ${projectName}\n\n| Req # | Requirement | Acceptance criteria | Test status | Last tested | Status |\n|-------|-------------|-------------------|-------------|-------------|--------|\n| (QA fills this from ROADMAP.md) | | | | | |\n`;
  writeFileSync(
    join(dir, '.planning', 'acceptance-matrix.md'),
    appendAcceptanceHints(baseAcceptanceMatrix, template.acceptance_hints)
  );
  writeFileSync(join(dir, '.planning', 'ship-verdict.md'), `# Ship Verdict — ${projectName}\n\n## Verdict: PENDING\n\n## QA Summary\n\n(QA writes the final ship/no-ship assessment here.)\n\n## Open Blockers\n\n(List any blocking issues.)\n\n## Conditions\n\n(List any conditions for shipping.)\n`);
  for (const artifact of template.planning_artifacts) {
    writeFileSync(
      join(dir, '.planning', artifact.filename),
      interpolateTemplateContent(artifact.content_template, projectName)
    );
  }

  // TALK.md
  writeFileSync(join(dir, 'TALK.md'), `# ${projectName} — Team Talk File\n\nCanonical human-readable handoff log for all agents.\n\n---\n\n`);

  // .gitignore additions
  const gitignorePath = join(dir, '.gitignore');
  const requiredIgnores = ['.env', '.agentxchain/staging/', '.agentxchain/dispatch/'];
  if (!existsSync(gitignorePath)) {
    writeFileSync(gitignorePath, requiredIgnores.join('\n') + '\n');
  } else {
    const existingIgnore = readFileSync(gitignorePath, 'utf8');
    const missing = requiredIgnores.filter(entry => !existingIgnore.split(/\r?\n/).includes(entry));
    if (missing.length > 0) {
      const prefix = existingIgnore.endsWith('\n') ? '' : '\n';
      writeFileSync(gitignorePath, existingIgnore + prefix + missing.join('\n') + '\n');
    }
  }

  return { config, state };
}

async function initGoverned(opts) {
  let projectName, folderName;
  const templateId = opts.template || 'generic';

  if (!VALID_GOVERNED_TEMPLATE_IDS.includes(templateId)) {
    console.error(chalk.red(`  Error: Unknown template "${templateId}".`));
    console.error('');
    console.error('  Available templates:');
    console.error('    generic       Default governed scaffold');
    console.error('    api-service   Governed scaffold for a backend service');
    console.error('    cli-tool      Governed scaffold for a CLI tool');
    console.error('    library       Governed scaffold for a reusable package');
    console.error('    web-app       Governed scaffold for a web application');
    process.exit(1);
  }

  if (opts.yes) {
    projectName = 'My AgentXchain Project';
    folderName = slugify(projectName);
  } else {
    const { name } = await inquirer.prompt([{
      type: 'input',
      name: 'name',
      message: 'Project name:',
      default: 'My AgentXchain Project'
    }]);
    projectName = name;
    folderName = slugify(projectName);

    const { folder } = await inquirer.prompt([{
      type: 'input',
      name: 'folder',
      message: 'Folder name:',
      default: folderName
    }]);
    folderName = folder;
  }

  const dir = resolve(process.cwd(), folderName);
  const projectId = slugify(projectName);
  let localDevRuntime;

  try {
    ({ runtime: localDevRuntime } = resolveGovernedLocalDevRuntime(opts));
  } catch (err) {
    console.error(chalk.red(`  Error: ${err.message}`));
    process.exit(1);
  }

  if (existsSync(dir) && existsSync(join(dir, CONFIG_FILE))) {
    if (!opts.yes) {
      const { overwrite } = await inquirer.prompt([{
        type: 'confirm',
        name: 'overwrite',
        message: `${folderName}/ already has agentxchain.json. Overwrite?`,
        default: false
      }]);
      if (!overwrite) {
        console.log(chalk.yellow('  Aborted.'));
        return;
      }
    }
  }

  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });

  scaffoldGoverned(dir, projectName, projectId, templateId, opts);

  console.log('');
  console.log(chalk.green(`  ✓ Created governed project ${chalk.bold(folderName)}/`));
  console.log('');
  console.log(`    ${chalk.dim('├──')} agentxchain.json  ${chalk.dim('(governed)')}`);
  console.log(`    ${chalk.dim('├──')} .agentxchain/`);
  console.log(`    ${chalk.dim('│')}    ${chalk.dim('├──')} state.json / history.jsonl / decision-ledger.jsonl`);
  console.log(`    ${chalk.dim('│')}    ${chalk.dim('├──')} staging/`);
  console.log(`    ${chalk.dim('│')}    ${chalk.dim('├──')} prompts/  ${chalk.dim('(pm, dev, qa, eng_director)')}`);
  console.log(`    ${chalk.dim('│')}    ${chalk.dim('├──')} reviews/`);
  console.log(`    ${chalk.dim('│')}    ${chalk.dim('└──')} dispatch/`);
  console.log(`    ${chalk.dim('├──')} .planning/`);
  console.log(`    ${chalk.dim('│')}    ${chalk.dim('├──')} PM_SIGNOFF.md / ROADMAP.md`);
  console.log(`    ${chalk.dim('│')}    ${chalk.dim('└──')} acceptance-matrix.md / ship-verdict.md`);
  console.log(`    ${chalk.dim('└──')} TALK.md`);
  console.log('');
  console.log(`  ${chalk.dim('Roles:')} pm, dev, qa, eng_director`);
  console.log(`  ${chalk.dim('Template:')} ${templateId}`);
  console.log(`  ${chalk.dim('Dev runtime:')} ${formatGovernedRuntimeCommand(localDevRuntime)} ${chalk.dim(`(${localDevRuntime.prompt_transport})`)}`);
  console.log(`  ${chalk.dim('Protocol:')} governed convergence`);
  console.log('');
  console.log(`  ${chalk.cyan('Next:')}`);
  console.log(`    ${chalk.bold(`cd ${folderName}`)}`);
  console.log(`    ${chalk.bold('agentxchain step')} ${chalk.dim('# run the first governed turn')}`);
  console.log(`    ${chalk.bold('agentxchain status')} ${chalk.dim('# inspect phase, gate, and turn state')}`);
  console.log('');
}

export async function initCommand(opts) {
  if (opts.governed || opts.schemaVersion === '4') {
    return initGoverned(opts);
  }

  let project, agents, folderName, rules;

  if (opts.yes) {
    project = 'My AgentXchain project';
    agents = DEFAULT_AGENTS;
    folderName = slugify(project);
    rules = {
      max_consecutive_claims: 2,
      require_message: true,
      compress_after_words: 5000,
      strict_next_owner: false
    };
  } else {
    const templates = loadTemplates();

    // Template selection
    const templateChoices = [
      { name: `${chalk.cyan('Custom')} — define your own agents`, value: 'custom' },
      { name: `${chalk.cyan('Default')} — PM, Dev, QA, UX (4 agents)`, value: 'default' },
      ...templates.map(t => ({
        name: `${chalk.cyan(t.label)} — ${t.description} (${Object.keys(t.agents).length} agents)`,
        value: t.id
      }))
    ];

    const { template } = await inquirer.prompt([{
      type: 'list',
      name: 'template',
      message: 'Choose a team template:',
      choices: templateChoices
    }]);

    if (template !== 'custom' && template !== 'default') {
      const tmpl = templates.find(t => t.id === template);
      agents = tmpl.agents;
      rules = tmpl.rules || {};
      const { projectName } = await inquirer.prompt([{
        type: 'input',
        name: 'projectName',
        message: 'Project name:',
        default: tmpl.project
      }]);
      project = projectName;
    } else if (template === 'default') {
      agents = DEFAULT_AGENTS;
      rules = {
      max_consecutive_claims: 2,
      require_message: true,
      compress_after_words: 5000,
      strict_next_owner: false
    };
      const { projectName } = await inquirer.prompt([{
        type: 'input',
        name: 'projectName',
        message: 'Project name:',
        default: 'My AgentXchain project'
      }]);
      project = projectName;
    } else {
      const { projectName } = await inquirer.prompt([{
        type: 'input',
        name: 'projectName',
        message: 'Project name:',
        default: 'My AgentXchain project'
      }]);
      project = projectName;
      agents = {};
      rules = {
      max_consecutive_claims: 2,
      require_message: true,
      compress_after_words: 5000,
      strict_next_owner: false
    };

      const { count } = await inquirer.prompt([{
        type: 'number',
        name: 'count',
        message: 'How many agents on this team?',
        default: 4,
        validate: v => (v >= 2 && v <= 20) ? true : 'Between 2 and 20 agents.'
      }]);

      console.log('');
      console.log(chalk.dim(`  Define ${count} agents. For each, provide a name and describe their role.`));
      console.log('');

      for (let i = 1; i <= count; i++) {
        console.log(chalk.cyan(`  Agent ${i} of ${count}`));

        const { name } = await inquirer.prompt([{
          type: 'input',
          name: 'name',
          message: `  Name (e.g. "Product Manager", "Backend Engineer"):`,
          validate: v => v.trim().length > 0 ? true : 'Name is required.'
        }]);

        const { mandate } = await inquirer.prompt([{
          type: 'editor',
          name: 'mandate',
          message: `  Role & responsibilities for ${name} (opens editor — describe what this agent does, what they produce each turn, how they challenge others):`,
          default: `You are the ${name} on this team.\n\nEVERY TURN YOU MUST PRODUCE:\n1. \n2. \n3. \n\nHOW YOU CHALLENGE OTHERS:\n- \n\nANTI-PATTERNS:\n- `,
          waitForUseInput: false
        }]);

        const id = slugify(name);
        const uniqueId = agents[id] ? `${id}-${i}` : id;

        if (uniqueId === 'human' || uniqueId === 'system') {
          agents[`${uniqueId}-agent`] = { name, mandate: mandate.trim() };
        } else {
          agents[uniqueId] = { name, mandate: mandate.trim() };
        }

        console.log(chalk.green(`  ✓ Added ${chalk.bold(name)} (${uniqueId})`));
        console.log('');
      }
    }

    folderName = slugify(project);
    const { folder } = await inquirer.prompt([{
      type: 'input',
      name: 'folder',
      message: 'Folder name:',
      default: folderName
    }]);
    folderName = folder;
  }

  const dir = resolve(process.cwd(), folderName);

  if (existsSync(dir) && existsSync(join(dir, CONFIG_FILE))) {
    if (!opts.yes) {
      const { overwrite } = await inquirer.prompt([{
        type: 'confirm',
        name: 'overwrite',
        message: `${folderName}/ already has agentxchain.json. Overwrite?`,
        default: false
      }]);
      if (!overwrite) {
        console.log(chalk.yellow('  Aborted.'));
        return;
      }
    }
  }

  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });

  const config = {
    version: 3,
    project,
    agents,
    log: 'log.md',
    talk_file: 'TALK.md',
    state_file: 'state.md',
    history_file: 'history.jsonl',
    rules: {
      max_consecutive_claims: rules.max_consecutive_claims || 2,
      require_message: rules.require_message !== false,
      compress_after_words: rules.compress_after_words || 5000,
      ttl_minutes: rules.ttl_minutes || 10,
      watch_interval_ms: rules.watch_interval_ms || 5000,
      strict_next_owner: rules.strict_next_owner === true,
      ...(rules.verify_command ? { verify_command: rules.verify_command } : {})
    }
  };

  const lock = { holder: 'human', last_released_by: null, turn_number: 0, claimed_at: new Date().toISOString() };
  const state = { phase: 'discovery', blocked: false, blocked_on: null, project };

  // Core protocol files
  writeFileSync(join(dir, CONFIG_FILE), JSON.stringify(config, null, 2) + '\n');
  writeFileSync(join(dir, LOCK_FILE), JSON.stringify(lock, null, 2) + '\n');
  writeFileSync(join(dir, 'state.json'), JSON.stringify(state, null, 2) + '\n');
  writeFileSync(join(dir, 'state.md'), `# ${project} — Current State\n\n## Architecture\n\n(Agents update this each turn with current decisions.)\n\n## Active Work\n\n(What's in progress right now.)\n\n## Open Issues\n\n(Bugs, blockers, risks.)\n\n## Next Steps\n\n(What should happen next.)\n`);
  writeFileSync(join(dir, 'history.jsonl'), '');
  writeFileSync(join(dir, 'log.md'), `# ${project} — Agent Log\n\n## COMPRESSED CONTEXT\n\n(No compressed context yet.)\n\n## MESSAGE LOG\n\n(Agents append messages below this line.)\n`);
  writeFileSync(join(dir, 'TALK.md'), `# ${project} — Team Talk File\n\nCanonical human-readable handoff log for all agents.\n\n## How to write entries\n\nUse this exact structure:\n\n## Turn N — <agent_id> (<role>)\n- Status:\n- Decision:\n- Action:\n- Risks/Questions:\n- Next owner:\n\n---\n\n`);
  writeFileSync(join(dir, 'HUMAN_TASKS.md'), '# Human Tasks\n\n(Agents append tasks here when they need human action.)\n');
  const gitignorePath = join(dir, '.gitignore');
  const requiredIgnores = ['.env', '.agentxchain-trigger.json', '.agentxchain-prompts/', '.agentxchain-workspaces/', '.agentxchain-watch.pid', '.agentxchain-autonudge.state'];
  if (!existsSync(gitignorePath)) {
    writeFileSync(gitignorePath, requiredIgnores.join('\n') + '\n');
  } else {
    const existingIgnore = readFileSync(gitignorePath, 'utf8');
    const missing = requiredIgnores.filter(entry => !existingIgnore.split(/\r?\n/).includes(entry));
    if (missing.length > 0) {
      const prefix = existingIgnore.endsWith('\n') ? '' : '\n';
      writeFileSync(gitignorePath, existingIgnore + prefix + missing.join('\n') + '\n');
    }
  }

  // .planning/ structure
  mkdirSync(join(dir, '.planning', 'research'), { recursive: true });
  mkdirSync(join(dir, '.planning', 'phases'), { recursive: true });
  mkdirSync(join(dir, '.planning', 'qa'), { recursive: true });

  writeFileSync(join(dir, '.planning', 'PROJECT.md'), `# ${project}\n\n## Vision\n\n(PM fills this on the first turn: who is the user, what problem are we solving, what does success look like.)\n\n## Constraints\n\n(Technical constraints, timeline, budget, dependencies.)\n\n## Stack\n\n(Tech stack decisions and rationale.)\n`);

  writeFileSync(join(dir, '.planning', 'REQUIREMENTS.md'), `# Requirements — ${project}\n\n## v1 (MVP)\n\n(PM fills this: numbered list of requirements. Each requirement has one-sentence acceptance criteria.)\n\n| # | Requirement | Acceptance criteria | Phase | Status |\n|---|-------------|-------------------|-------|--------|\n| 1 | | | | Pending |\n\n## v2 (Future)\n\n(Out of scope for MVP. Captured here so they don't creep in.)\n\n## Out of scope\n\n(Explicitly not building.)\n`);

  writeFileSync(join(dir, '.planning', 'ROADMAP.md'), `# Roadmap — ${project}\n\n## Waves\n\n| Wave | Goal | Status |\n|------|------|--------|\n| Wave 1 | Discovery, planning, and phase setup | In progress |\n\n## Phases\n\n| Phase | Description | Status | Requirements |\n|-------|-------------|--------|-------------|\n| 1 | Discovery + setup | In progress | — |\n\n(PM updates this as phases are planned and completed.)\n`);
  writeFileSync(join(dir, '.planning', 'PM_SIGNOFF.md'), `# PM Signoff — ${project}\n\nApproved: NO\n\n## Discovery Checklist\n- [ ] Target user defined\n- [ ] Core pain point defined\n- [ ] Core workflow defined\n- [ ] MVP scope defined\n- [ ] Out-of-scope list defined\n- [ ] Success metric defined\n\n## Notes for team\n(PM and human add final kickoff notes here.)\n`);

  // QA structure
  mkdirSync(join(dir, '.planning', 'phases', 'phase-1'), { recursive: true });
  writeFileSync(join(dir, '.planning', 'phases', 'phase-1', 'PLAN.md'), `# Phase 1 Plan — ${project}\n\n## Goal\n\nAlign scope, requirements, and initial implementation plan.\n\n## Deliverables\n\n- PM signoff\n- Initial requirements and roadmap\n- First implementation slice\n`);
  writeFileSync(join(dir, '.planning', 'phases', 'phase-1', 'TESTS.md'), `# Phase 1 Tests — ${project}\n\n## Planned checks\n\n- Kickoff validation passes\n- Requirements have acceptance criteria\n- First implementation slice has an executable verification path\n`);
  writeFileSync(join(dir, '.planning', 'qa', 'TEST-COVERAGE.md'), `# Test Coverage — ${project}\n\n## Coverage Map\n\n| Feature / Area | Unit tests | Integration tests | E2E tests | Manual QA | UX audit | Status |\n|---------------|-----------|------------------|----------|----------|---------|--------|\n| (QA fills this as testing progresses) | | | | | | |\n\n## Coverage gaps\n\n(Areas with no tests or insufficient coverage.)\n`);

  writeFileSync(join(dir, '.planning', 'qa', 'REGRESSION-LOG.md'), `# Regression Log — ${project}\n\nBugs that were found and fixed. Each entry has a regression test to prevent recurrence.\n\n| Bug ID | Description | Found turn | Fixed turn | Regression test | Status |\n|--------|-------------|-----------|-----------|----------------|--------|\n| (QA adds entries as bugs are found and fixed) | | | | | |\n`);

  writeFileSync(join(dir, '.planning', 'qa', 'ACCEPTANCE-MATRIX.md'), `# Acceptance Matrix — ${project}\n\nMaps every requirement to its test status. This is the definitive "can we ship?" document.\n\n| Req # | Requirement | Acceptance criteria | Functional test | UX test | Last tested | Status |\n|-------|-------------|-------------------|-----------------|---------|-------------|--------|\n| (QA fills this from REQUIREMENTS.md) | | | | | | |\n`);

  writeFileSync(join(dir, '.planning', 'qa', 'UX-AUDIT.md'), `# UX Audit — ${project}\n\n## Audit checklist\n\nQA updates this every turn when the project has a user interface.\n\n### First impressions (< 5 seconds)\n- [ ] Is it immediately clear what this product does?\n- [ ] Can the user find the primary action without scrolling?\n- [ ] Does the page load in under 2 seconds?\n\n### Navigation & flow\n- [ ] Can the user complete the core workflow without getting lost?\n- [ ] Are there dead ends (pages with no next action)?\n- [ ] Does the back button work as expected?\n\n### Forms & input\n- [ ] Do all form fields have labels?\n- [ ] Are error messages specific (not just "invalid input")?\n- [ ] Is there feedback after submission (loading state, success message)?\n- [ ] Do forms work with autofill?\n\n### Visual consistency\n- [ ] Is spacing consistent across pages?\n- [ ] Are fonts consistent (max 2 font families)?\n- [ ] Are button styles consistent?\n- [ ] Are colors consistent with the design system?\n\n### Responsive\n- [ ] Does it work on mobile (375px)?\n- [ ] Does it work on tablet (768px)?\n- [ ] Does it work on desktop (1440px)?\n- [ ] Are touch targets at least 44x44px on mobile?\n\n### Accessibility\n- [ ] Do all images have alt text?\n- [ ] Is color contrast WCAG AA compliant (4.5:1 for text)?\n- [ ] Can the entire app be navigated by keyboard?\n- [ ] Do focus states exist for interactive elements?\n- [ ] Are headings in correct hierarchy (h1 > h2 > h3)?\n\n### Error states\n- [ ] What does the user see when the network is offline?\n- [ ] What does the user see when the server returns 500?\n- [ ] What does the user see on an empty state (no data yet)?\n\n## Issues found\n\n| # | Issue | Severity | Page/Component | Screenshot/Description | Status |\n|---|-------|----------|---------------|----------------------|--------|\n| (QA adds UX issues here) | | | | | |\n`);

  writeFileSync(join(dir, '.planning', 'qa', 'BUGS.md'), `# Bugs — ${project}\n\n## Open\n\n(QA adds bugs here with reproduction steps.)\n\n## Fixed\n\n(Bugs move here when dev confirms the fix and QA verifies it.)\n`);

  // VS Code agent files (.github/agents/, .github/hooks/, scripts/)
  const vsResult = generateVSCodeFiles(dir, config);

  const agentCount = Object.keys(agents).length;
  const kickoffId = pickPmKickoffId(agents);
  console.log('');
  console.log(chalk.green(`  ✓ Created ${chalk.bold(folderName)}/`));
  console.log('');
  console.log(`    ${chalk.dim('├──')} agentxchain.json  ${chalk.dim(`(${agentCount} agents)`)}`);
  console.log(`    ${chalk.dim('├──')} lock.json`);
  console.log(`    ${chalk.dim('├──')} state.json / state.md / history.jsonl`);
  console.log(`    ${chalk.dim('├──')} TALK.md / log.md / HUMAN_TASKS.md`);
  console.log(`    ${chalk.dim('├──')} .planning/`);
  console.log(`    ${chalk.dim('│')}    ${chalk.dim('├──')} PROJECT.md / REQUIREMENTS.md / ROADMAP.md / PM_SIGNOFF.md`);
  console.log(`    ${chalk.dim('│')}    ${chalk.dim('├──')} research/ / phases/`);
  console.log(`    ${chalk.dim('│')}    ${chalk.dim('└──')} qa/  ${chalk.dim('TEST-COVERAGE / BUGS / UX-AUDIT / ACCEPTANCE-MATRIX')}`);
  console.log(`    ${chalk.dim('├──')} .github/agents/  ${chalk.dim(`(${agentCount} .agent.md files)`)}`);
  console.log(`    ${chalk.dim('├──')} .github/hooks/   ${chalk.dim('agentxchain.json')}`);
  console.log(`    ${chalk.dim('└──')} scripts/         ${chalk.dim('hook shell scripts')}`);
  console.log('');
  console.log(`  ${chalk.dim('Agents:')} ${Object.keys(agents).join(', ')}`);
  console.log('');
  console.log(`  ${chalk.cyan('Next:')}`);
  console.log(`    ${chalk.bold(`cd ${folderName}`)}`);
  console.log(`    ${chalk.bold(`agentxchain start --agent ${kickoffId}`)} ${chalk.dim('# PM-first kickoff: align scope with human')}`);
  console.log(`    ${chalk.bold('agentxchain start --remaining')} ${chalk.dim('# launch rest of team after PM planning')}`);
  console.log(`    ${chalk.bold('agentxchain supervise --autonudge')} ${chalk.dim('# watch + AppleScript nudge loop')}`);
  console.log(`    ${chalk.bold('agentxchain release')} ${chalk.dim('# release human lock when you are ready')}`);
  console.log('');
}

function pickPmKickoffId(agents) {
  if (agents.pm) return 'pm';
  for (const [id, def] of Object.entries(agents || {})) {
    const name = String(def?.name || '').toLowerCase();
    if (name.includes('product manager')) return id;
  }
  return Object.keys(agents || {})[0] || 'pm';
}
