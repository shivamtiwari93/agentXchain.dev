import { execSync } from 'child_process';
import { writeFileSync, mkdirSync } from 'fs';
import { join } from 'path';
import chalk from 'chalk';
import inquirer from 'inquirer';
import { generatePollingPrompt } from '../lib/seed-prompt-polling.js';
import { filterAgents } from '../lib/filter-agents.js';

export async function launchCursorLocal(config, root, opts) {
  const agents = filterAgents(config, opts.agent);
  const agentEntries = Object.entries(agents);
  const total = agentEntries.length;
  const selectedAgent = opts.agent ? agents[opts.agent] : null;
  const isPmKickoff = !!selectedAgent && isPmLike(opts.agent, selectedAgent) && !opts.remaining;

  console.log(chalk.bold(`  Setting up ${total} agents: ${Object.keys(agents).join(', ')}`));
  if (isPmKickoff) {
    console.log(chalk.dim('  PM kickoff mode: start with human-PM planning before launching the full team.'));
  }
  console.log('');

  const promptDir = join(root, '.agentxchain-prompts');
  mkdirSync(promptDir, { recursive: true });

  // Save all prompts first
  for (const [id, agent] of agentEntries) {
    const prompt = isPmKickoff
      ? generateKickoffPrompt(id, agent, config, root)
      : generatePollingPrompt(id, agent, config, root);
    writeFileSync(join(promptDir, `${id}.prompt.md`), prompt);
  }

  // Create per-agent workspace files so each Cursor window has a unique identity
  const workspacesDir = join(root, '.agentxchain-workspaces');
  mkdirSync(workspacesDir, { recursive: true });

  for (let i = 0; i < agentEntries.length; i++) {
    const [id, agent] = agentEntries[i];
    const prompt = isPmKickoff
      ? generateKickoffPrompt(id, agent, config, root)
      : generatePollingPrompt(id, agent, config, root);

    // Create workspace file: .agentxchain-workspaces/<id>.code-workspace
    const agentWorkspace = join(workspacesDir, `${id}.code-workspace`);
    const workspaceJson = {
      folders: [{ path: root }],
      settings: { 'agentxchain.agentId': id }
    };
    writeFileSync(agentWorkspace, JSON.stringify(workspaceJson, null, 2) + '\n');

    console.log(chalk.cyan(`  ─── Agent ${i + 1}/${total}: ${chalk.bold(id)} — ${agent.name} ───`));
    console.log('');

    const copied = copyToClipboard(prompt);
    if (copied) {
      console.log(chalk.green('  ✓ Prompt copied to clipboard.'));
    } else {
      console.log(chalk.yellow('  ! Clipboard copy failed. Use the saved prompt file manually.'));
    }
    console.log(chalk.dim(`    Saved to: .agentxchain-prompts/${id}.prompt.md`));

    // Open a separate Cursor window using the symlinked path
    const opened = openCursorWindow(agentWorkspace);
    if (opened) {
      console.log(chalk.dim(`    Cursor window opened for ${id}.`));
    } else {
      console.log(chalk.yellow(`    Could not open Cursor window automatically for ${id}.`));
      console.log(chalk.dim(`    Open manually: cursor --new-window "${agentWorkspace}"`));
    }

    console.log('');
    console.log(`  ${chalk.bold('In the new Cursor window:')}`);
    console.log(`    1. Open chat (${chalk.bold('Cmd+L')})`);
    console.log(`    2. Paste the prompt (${chalk.bold('Cmd+V')})`);
    if (isPmKickoff) {
      console.log(`    3. ${chalk.bold('Select Agent mode')} and discuss requirements with PM`);
      console.log(`    4. Update planning docs together (PROJECT / REQUIREMENTS / ROADMAP)`);
    } else {
      console.log(`    3. ${chalk.bold('Select Agent mode')} (not Ask/Edit)`);
      console.log(`    4. Send it (${chalk.bold('Enter')})`);
    }

    if (i < agentEntries.length - 1) {
      console.log('');
      await inquirer.prompt([{
        type: 'input',
        name: 'ready',
        message: `  Done? Press Enter to open next window (${agentEntries[i + 1][0]})...`
      }]);
      console.log('');
    } else {
      console.log('');
      console.log(chalk.dim(`  Last agent. Paste and send, then come back here.`));
      console.log('');
    }
  }

  console.log(chalk.green(`  ✓ All ${total} agents launched in separate Cursor windows.`));
  console.log('');
  console.log(`  ${chalk.cyan('Now run:')}`);
  if (isPmKickoff) {
    console.log(`    ${chalk.bold('agentxchain start --remaining')} ${chalk.dim('# launch the rest of the team when PM plan is ready')}`);
    console.log(`    ${chalk.bold('agentxchain supervise --autonudge')} ${chalk.dim('# start watch + auto-nudge')}`);
    console.log(`    ${chalk.bold('agentxchain release')} ${chalk.dim('# release human lock to begin team turns')}`);
  } else {
    console.log(`    ${chalk.bold('agentxchain supervise --autonudge')} ${chalk.dim('# recommended: watch + auto-nudge in one command')}`);
    console.log(`    ${chalk.bold('agentxchain release')} ${chalk.dim('# release human lock — agents start claiming turns')}`);
  }
  console.log('');
  console.log(`  ${chalk.dim('Other commands:')}`);
  console.log(`    ${chalk.bold('agentxchain status')}   ${chalk.dim('# check who holds the lock')}`);
  console.log(`    ${chalk.bold('agentxchain claim')}    ${chalk.dim('# pause agents and take control')}`);
  console.log(`    ${chalk.bold('agentxchain watch')}    ${chalk.dim('# watcher / trigger writer')}`);
  console.log(`    ${chalk.bold('agentxchain doctor')}   ${chalk.dim('# check local setup + trigger health')}`);
  console.log('');
  console.log(chalk.dim('  Agents run single turns. Watch/supervise wakes the correct next agent.'));
  console.log(chalk.dim('  Re-paste a prompt: cat .agentxchain-prompts/<agent>.prompt.md | pbcopy'));
  console.log('');
}

function copyToClipboard(text) {
  try {
    if (process.platform === 'darwin') {
      execSync('pbcopy', { input: text, encoding: 'utf8' });
      return true;
    }
    if (process.platform === 'linux') {
      execSync('xclip -selection clipboard', { input: text, encoding: 'utf8' });
      return true;
    }
  } catch {}
  return false;
}

function openCursorWindow(folderPath) {
  try {
    if (process.platform === 'darwin') {
      execSync(`open -na "Cursor" --args "${folderPath}"`, { stdio: 'ignore' });
      return true;
    }
    execSync(`cursor --new-window "${folderPath}"`, { stdio: 'ignore' });
    return true;
  } catch {}
  return false;
}

function isPmLike(agentId, agentDef) {
  if (agentId === 'pm') return true;
  const name = String(agentDef?.name || '').toLowerCase();
  return name.includes('product manager');
}

function generateKickoffPrompt(agentId, agentDef, config, projectRoot) {
  return `You are "${agentId}" — ${agentDef.name}.

This is PM kickoff mode. Your job now is to collaborate with the human and finalize scope before autonomous turns begin.

Project root (strict boundary): "${projectRoot}"
Work only inside this project folder. Do NOT scan unrelated local directories.

Actions:
1) FIRST QUESTION TO HUMAN (mandatory before anything else):
"Please describe your product idea in one paragraph, in as much detail as possible."

2) Read:
- .planning/PROJECT.md
- .planning/REQUIREMENTS.md
- .planning/ROADMAP.md
- TALK.md
- state.md
- lock.json
3) After receiving that paragraph, summarize it in TALK.md, then ask focused follow-up questions:
- target user
- top pain point
- core workflow
- MVP boundary
- success metric
4) Update planning docs with concrete acceptance criteria and Get Shit Done structure:
- .planning/ROADMAP.md must define Waves and Phases.
- Create .planning/phases/phase-1/PLAN.md and TESTS.md.
5) Update .planning/PM_SIGNOFF.md:
- Set "Approved: YES" only when human agrees kickoff is complete.
6) Append kickoff summary to TALK.md with:
- Status
- Decision
- Action
- Risks/Questions
- Next owner
7) Do NOT start round-robin agent handoffs yet.

Context:
- Project: ${config.project}
- Human currently holds lock.
- Once planning is approved, human will launch remaining agents and run release.`;
}
